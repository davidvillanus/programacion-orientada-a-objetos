package MatrizA;

public class Main {

	public static void main( String args[] )
	{
	    int Array1[][] = {{1,2,3},{4,5,6},{7,8,9}};
	    
	    System.out.println("Valores diagonales 1: ");
	    outputArray(Array1);
	}


public static void outputArray( int Array[][] ) {

    for(int row = 0; row < Array.length; row++)
    {
        for(int column = 0; column < Array[row].length; column++)
        {
            if(row==column)
            {
            System.out.printf( "%d" , Array[row][column]);
            }
        }
    System.out.println();
    }

}

}
