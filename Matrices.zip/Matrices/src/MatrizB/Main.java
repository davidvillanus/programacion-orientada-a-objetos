package MatrizB;

public class Main {

	public static void main( String args[] )
	{
	    String Array1[][] = {{"a","b","c","d"},{"e","f","g","h"},{"i","j","k","l"},{"m","n","o","p"}};

	    System.out.println("Valores diagonales 1: ");
	    outputArray(Array1);
	}

public static void outputArray( String Array[][] ) {

    for(int row = 0; row < Array.length; row++)
    {
        for(int column = 0; column < Array[row].length; column++)
        {
            if(row == column)
            {
            System.out.print(Array[row][column]);
            }
        }
    System.out.println();
    }

}

}
