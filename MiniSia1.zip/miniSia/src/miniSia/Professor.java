package miniSia;

import java.util.List;

public class Professor {
	
	private long id;
	private String usuario;
	private String nombre;
	private String apellido;
	private int edad;
	private List<Group> grupoTomado;
	
	public long getid() {
		return this.id;
	}
	
	public String getUsuario() {
		return this.usuario;
	}
	
	public String getNombre() {
		return this.nombre;
	}

	public String getApellido() {
		return this.apellido;
	}
	
	public int getEdad() {
		return this.edad;
	}

	public List<Group> getGrupoTomado() {
		return this.grupoTomado;
	}
	
	public void setId(long id) {
		this.id = id;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}
	
	public void setEdad(int edad) {
		this.edad = edad;
	}
	
	public void setGrupo(List<Group> grupoTomado) {
		this.grupoTomado = grupoTomado;
	}
	
}
