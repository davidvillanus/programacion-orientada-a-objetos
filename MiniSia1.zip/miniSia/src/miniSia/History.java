package miniSia;

public class History {
	
	Student estudiante;
	Course curso;
	Grade nota;
	Semester semestre;
	
	public Student getEstudiante() {
		return this.estudiante;
	}
	
	public Course getCurso() {
		return this.curso;
	}
	
	public Grade getNota() {
		return this.nota;
	}
	
	public Semester getSemestre() {
		return this.semestre;
	}
	
	public void setEstudiante(Student estudiante) {
		this.estudiante = estudiante;
	}
	
	public void setCurso(Course curso) {
		this.curso = curso;
	}
	
	public void setNota(Grade nota) {
		this.nota = nota;
	}
	
	public void setSemestre(Semester semestre) {
		this.semestre = semestre;
	}

}
