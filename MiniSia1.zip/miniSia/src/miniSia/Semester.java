package miniSia;

public class Semester {
	
	private int a�o;
	private String semestre;
	
	public int getA�o() {
		return this.a�o;
	}
	
	public String getSemestre() {
		return this.semestre;
	}
	
	public void setA�o(int a�o) {
		this.a�o = a�o;
	}
	
	public void setSemestre(String semestre) {
		this.semestre = semestre;
	}

}
