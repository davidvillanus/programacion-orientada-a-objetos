package miniSia;

public class Grade {

	Student estudiante;
	Course curso;
	Group grupo;
	double nota;
	
	public Student getEstudiante() {
		return this.estudiante;
	}
	
	public Group getGrupo() {
		return this.grupo;
	}
	
	public double getGrade() {
		return this.nota;
	}
	
	public Course getCurso() {
		return this.curso;
	}
	
	public void setEstudiante(Student estudiante) {
		this.estudiante = estudiante;
	}
	
	public void setGrupo(Group grupo) {
		this.grupo = grupo;
	}
	
	public void setNota(double nota) {
		this.nota = nota;
	}

	public void setCurso(Course curso) {
		this.curso = curso;
	}
	
}
