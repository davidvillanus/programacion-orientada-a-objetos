package miniSia;

import java.util.List;

public class Group {

	private long numero;
	private String[] diasSemana;
	private String[] horasDia;
	private Semester semestre;
	private Course curso;
	private Professor dadoPor;
	private List<Student> tomadoPor;
	private List<Grade> notas;
	
	public long getNumero() {
		return this.numero;
	}
	
	public String[] getDiasSemana() {
		return this.diasSemana;
	}
	
	public String[] getHorasDia() {
		return this.horasDia;
	}
	
	public Semester getSemestre() {
		return this.semestre;
	}
	
	public Course getCurso() {
		return this.curso;
	}
	
	public Professor getDadoPor() {
		return this.dadoPor;
	}
	
	public List<Student> getTomadoPor() {
		return this.tomadoPor;
	}
	
	public List<Grade> getNotas() {
		return this.notas;
	}
	
	public void setNumero(long numero) {
		this.numero = numero;
	}
	
	public void setDiasSemana(String[] diasSemana) {
		this.diasSemana = diasSemana;
	}
	
	public void setHorasDia(String[] horasDia) {
		this.horasDia = horasDia;
	}
	
	public void setSemestre(Semester semestre) {
		this.semestre = semestre;
	}
	
	public void setCurso(Course curso) {
		this.curso = curso;
	}
	
	public void setDadopor(Professor dadoPor) {
		this.dadoPor = dadoPor;
	}
	
	public void setTomadopor(List<Student> tomadoPor) {
		this.tomadoPor = tomadoPor;
	}
	
	public void setNotas(List<Grade> notas) {
		this.notas = notas;
	}
	
}
