package miniSia;

import java.util.List;

public class Course {
	
	private int numero;
	private String nombre;
	private List<Group> ofertado;
	
	public int getNumero() {
		return this.numero;
	}  
	
	public String getNombre() {
		return this.nombre;
	}  
	
	public List<Group> getGrupo() {
		return this.ofertado;
	}
	
	public void setNumero(int numero) {
		this.numero = numero;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}  
	
	public void setGrupo(List<Group> ofertado) {
		this.ofertado = ofertado;
	} 
	
}
