package MiniS1;

import java.util.ArrayList;

public class Programa_academico {
        //METODO//
        private String nombre;
        private int codigo;
        private ArrayList<Profesor> profesores;
        private ArrayList<Estudiante> estudiantes;
        private ArrayList<Curso>cursos;
    
        //ATRIBUTOS//
        public String getNombre(){
            return this.nombre;
        }
        public int getCodigo(){
            return this.codigo;
        }
        public ArrayList<Profesor> getProfesores(){
            return this.profesores;
        }
        public ArrayList<Estudiante> getEstudiantes(){
            return this.estudiantes;
        }
        public ArrayList<Curso> getCursos(){
            return this.cursos;
        }
        public void setNombre(String nombre){
            this.nombre=nombre;
        }
        public void setCodigo(int codigo){
            this.codigo=codigo;
        }
        public void setProfesores(ArrayList<Profesor> profesores){
            this.profesores=profesores;
        }
        public void setEstudiantes(ArrayList<Estudiante> estudiantes){
            this.estudiantes=estudiantes;
        }
        public void setCursos(ArrayList<Curso> cursos){
            this.cursos=cursos;
        }


    
}
