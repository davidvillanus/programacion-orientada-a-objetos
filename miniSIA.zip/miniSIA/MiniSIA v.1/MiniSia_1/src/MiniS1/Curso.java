package MiniS1;

import java.util.ArrayList;

public class Curso {
    //metodos//
    private String nombre;
    private int codigo;
    private int NumeroCreditos;
    private ArrayList<Grupo> grupos;
    private ArrayList<Profesor>profesores;

    //atributos//
    public String getNombre(){
        return this.nombre;   
    }
    public int getCodigo(){
        return this.codigo;
    }
    public int getNumeroCreditos(){
        return this.NumeroCreditos;
    }
    public ArrayList<Grupo> getGrupos(){
        return this.grupos;
    }

    public ArrayList<Profesor> getProfesores(){
        return this.profesores;
    }
    public void setNombre(String nombre){
        this.nombre=nombre;
    }
    public void setCodigo(int codigo){
        this.codigo=codigo;
    }
    public void setNumeroCreditos(int NumeroCreditos){
        this.NumeroCreditos=NumeroCreditos;
    }
    public void setGrupos(ArrayList<Grupo> grupos){
        this.grupos=grupos;
    }
    public void setProfesores(ArrayList<Profesor> profesores){
        this.profesores=profesores;
    }      

}
