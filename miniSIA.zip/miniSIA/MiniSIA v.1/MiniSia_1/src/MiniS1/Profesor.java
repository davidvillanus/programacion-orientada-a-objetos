package MiniS1;

import java.util.ArrayList;

public class Profesor {

    //METODO//
    private String nombre;
    private String apellido;
    private long Id;
    private String usuario;
    private Programa_academico programaAcademico;
    private ArrayList<Curso> cursos;
    private ArrayList<Grupo> grupos;

    //ATRIBUTOS//
    public String getNombre(){
        return this.nombre;
    }
    public String getApellido(){
        return this.apellido;
    }
    public long getId(){
        return this.Id;
    }
    public String getUsuario(){
        return this.usuario;    
    }

    public Programa_academico getProgramaAcademico(){
        return this.programaAcademico;
    }

    public ArrayList<Curso> getCursos(){
        return this.cursos;
    }
    public ArrayList<Grupo> getGrupos(){
        return this.grupos;
    }
    public void setNombre(String nombre){
        this.nombre=nombre;
    }
    public void setApellido(String apellido){
        this.apellido=apellido;
    }
    public void setId(long Id){
        this.Id=Id;
    }
    public void setUsuario(String usuario){
        this.usuario=usuario;
    }
    public void setProgramaAcademico(Programa_academico programaAcademico){
        this.programaAcademico=programaAcademico;
    }

    public void setCursos(ArrayList<Curso> cursos){
        this.cursos=cursos;
    }
    public void setGrupos(ArrayList<Grupo> grupos){
        this.grupos=grupos;
    }
}
