package MiniS1;

public class Credito {
    //metodos//
    private int aprobados;
    private int disponibles;
    private int inscritos;

    //atributos//
    public int getAprobados(){
        return this.aprobados;
    }
    public int getDisponibles(){
        return this.disponibles;
    }
    public int getInscritos(){
        return this.inscritos;
    }
    public void setAprobados(int aprobados){
        this.aprobados=aprobados;
    }
    public void setDisponibles(int disponibles){
        this.disponibles=disponibles;
    }
    public void setInscritos(int inscritos){
        this.inscritos=inscritos;
    }
    

    
}
