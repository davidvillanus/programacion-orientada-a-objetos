package MiniS1;

import java.util.ArrayList;

public class Grupo {
        //METODO//
        private int numero;
        private String[]diasDeLaSemana;
        private String[]horasDelDia;
        private Profesor profesor;
        private Curso curso;
        private ArrayList<Estudiante> estudiantes;
        private ArrayList<Nota> Notas;
        //ATRIBUTOS//


        public int getNumero(){
            return this.numero;
        }
        public String [] getDiasDeLaSemana(){
            return this.diasDeLaSemana;  
        }
        public String [] getHorasDelDia(){
            return this.horasDelDia;  
        }
        public Profesor getProfesor(){
            return this.profesor;    
        }
        public Curso getCurso(){
            return this.curso;    
        }
        public ArrayList<Estudiante> getEstudiantes(){
            return this.estudiantes;
        }
        public ArrayList<Nota> getNotas(){
            return this.Notas;
        }

        public void setNumero(int numero){
            this.numero=numero;
        }
        public void setDiasDeLaSemana(String [] diasDeLaSemana){
            this.diasDeLaSemana=diasDeLaSemana;  
        }
        public void setHorasDelDia(String [] horasDelDia){
            this.horasDelDia=horasDelDia;  
        }
        public void setProfesor(Profesor profesor){
            this.profesor=profesor;
        }
        public void setCurso(Curso curso){
            this.curso=curso;
        }
        public void setEstudiantes(ArrayList<Estudiante> estudiantes){
            this.estudiantes=estudiantes;
        }
        public void setNotas(ArrayList<Nota> Notas){
            this.Notas=Notas;
        }
    
}
