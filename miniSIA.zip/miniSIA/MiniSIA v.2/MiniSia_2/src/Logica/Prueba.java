package Logica;
import IU.Interfaz;




import Datos.Credito;
import Datos.Curso;
import Datos.Estudiante;
import Datos.Grupo;
import Datos.Nota;
import Datos.Profesor;
import Datos.Programa_academico;

public class Prueba {
    public static void main(String[] args){ 
        Interfaz.imprimirBienvenida ();

        //instanciacion de estudiantes
        
        Estudiante julieta=new Estudiante("julieta","amaya",101,"jamaya",4.0); 
        Estudiante juan = new Estudiante("juan","dias");
        Estudiante SinId = new Estudiante();
        
        //instanciacion de profesores
        Profesor miguel= new Profesor("miguel","ruiz",201,"mruiz");
        Profesor sara= new Profesor("sara","saenz");
        Profesor NoID= new Profesor();

        //instanciacion de creditos
        Credito creditosJulieta=new Credito(julieta, 50,130,20);
        Credito creditosJuan=new Credito(juan,40,160);
        Credito creditosSinId=new Credito(SinId,0,0);

        //instanciacion de curso *
        Curso calculo=new Curso("calculo",301,4);
        Curso programacion =new Curso("programacion basica",302,4);
        Curso NoO=new Curso();

        //instanciacion de grupo*
        String[] N1Dias = {"Lunes","Martes"};
        String[] N1Horas = {"9 am a 11 am"};
        String[] N2Dias = {"Lunes","Martes"};
        String[] N2Horas = {"11 am a 1 pm"};
        
        Grupo N1 =new Grupo(1,N1Dias,N1Horas,miguel,calculo);
        Grupo N2 =new Grupo(2,N2Dias,N2Horas,NoID,programacion);
        Grupo sinDefinir =new Grupo(0,null,null,NoID,NoO);

        //instanciacion de notas 
        Nota NotaJl= new Nota(julieta,calculo,N1,4.0);
        Nota NotaJn= new Nota(juan,programacion,N2,3.5);
        Nota NotaSinId= new Nota(SinId,NoO,sinDefinir,0);
        //instanciacion de programa academico
        Programa_academico matematicas = new Programa_academico("matematicas",401);
        Programa_academico computacion = new Programa_academico("computacion",402);
        Programa_academico sinC = new Programa_academico();
        julieta.setProgramaAcademico(matematicas);
        juan.setProgramaAcademico(matematicas);
        SinId.setProgramaAcademico(computacion);



        Interfaz.imprimirInformacion();
        //escribir con teclado
        int opcion= Interfaz.leerTeclado();
        switch (opcion) {
            case 1:
                System.out.println(julieta.toString());
                System.out.println(juan.toString());
                System.out.println(SinId.toString());
                break;
            case 2:
                System.out.println(miguel.toString());
                System.out.println(sara.toString());
                System.out.println(NoID.toString());
                break;
            case 3:
                System.out.println(calculo.toString());
                System.out.println(programacion.toString());
                System.out.println(NoO.toString());
                break;
            case 4:
                System.out.println(matematicas.toString());
                System.out.println(computacion.toString());
                System.out.println(sinC.toString());
                break;
            case 5:
                System.out.println(NotaJl.toString());
                System.out.println(NotaJn.toString());
                System.out.println(NotaSinId.toString());
                break;
            case 6:
                System.out.println(N1.toString());
                System.out.println(N2.toString());
                System.out.println(sinDefinir.toString());
                break;
            case 7:
                System.out.println(creditosJulieta.toString());
                System.out.println(creditosJuan.toString());
                System.out.println(creditosSinId.toString());
                break;
            default:
                System.out.println("ERROR");
                break;
        }
        


    }

    
}
