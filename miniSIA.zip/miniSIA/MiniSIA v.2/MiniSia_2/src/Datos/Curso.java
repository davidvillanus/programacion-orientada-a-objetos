package Datos;

import java.util.ArrayList;

public class Curso {
    //metodos//
    private String nombre;
    private int codigo;
    private int NumeroCreditos;
    private ArrayList<Grupo> grupos;
    private ArrayList<Profesor>profesores;
    //constructores//
    public Curso(String nombre,int codigo,int NumeroCreditos,ArrayList<Grupo> grupos,ArrayList<Profesor>profesores){
        this.setNombre(nombre);
        this.setCodigo(codigo);
        this.setNumeroCreditos(NumeroCreditos);
        this.setGrupos(grupos);
        this.setProfesores(profesores);
    }
    public Curso(String nombre,int codigo,int NumeroCreditos,ArrayList<Profesor>profesores){
        this(nombre,codigo,NumeroCreditos,null,profesores);
    }
    public Curso(String nombre,int codigo,int NumeroCreditos){
        this(nombre,codigo,NumeroCreditos,null,null);
    }
    public Curso(){
        this("nombre",0000,0,null,null);
    }
    //METODO TO STRING//
    @Override
    public String toString() {
        return "\n"+"nombre: "+this.getNombre()+"\n"+
        "codigo: "+this.getCodigo()+"\n"+
        "numero de creditos: "+this.getNumeroCreditos()
        //"grupos: "+this.getGrupos()+"\n"+"profesores: "+this.getProfesores()+"\n"
        ;
    }    
    //atributos//
    public String getNombre(){
        return this.nombre;   
    }
    public int getCodigo(){
        return this.codigo;
    }
    public int getNumeroCreditos(){
        return this.NumeroCreditos;
    }
    public ArrayList<Grupo> getGrupos(){
        return this.grupos;
    }

    public ArrayList<Profesor> getProfesores(){
        return this.profesores;
    }
    public void setNombre(String nombre){
        this.nombre=nombre;
    }
    public void setCodigo(int codigo){
        this.codigo=codigo;
    }
    public void setNumeroCreditos(int NumeroCreditos){
        this.NumeroCreditos=NumeroCreditos;
    }
    public void setGrupos(ArrayList<Grupo> grupos){
        this.grupos=grupos;
    }
    public void setProfesores(ArrayList<Profesor> profesores){
        this.profesores=profesores;
    }      

}
