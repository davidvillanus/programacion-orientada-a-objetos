package Datos;

import java.util.ArrayList;

public class Estudiante {
    //METODO//
    private String nombre;
    private String apellido;
    private long Id;
    private String usuario;
    private double promedio;
    private Programa_academico programaAcademico;
    private Credito creditos;
    private ArrayList<Curso> cursos;
    private ArrayList<Grupo> grupos;
    private ArrayList<Nota> notas;
    //constructores//
    public Estudiante(String nombre,String apellido,long Id,String usuario,double promedio,
    Programa_academico programa_academico,Credito creditos,ArrayList<Curso> cursos,
    ArrayList<Grupo> grupos,ArrayList<Nota> notas){
        this.setNombre(nombre);
        this.setApellido(apellido);
        this.setId(Id);
        this.setUsuario(usuario);
        this.setPromedio(promedio);
        this.setProgramaAcademico(programaAcademico);
        this.setCreditos(creditos);
        this.setCursos(cursos);
        this.setGrupos(grupos);
        this.setNotas(notas);
    }
    public Estudiante(String nombre,String apellido,long Id,String usuario,double promedio){
        this(nombre,apellido,Id,usuario,promedio,null,null,null,null,null);   
    }
    public Estudiante(String nombre,String apellido){
        this(nombre,apellido,0,"usuario",0,null,null,null,null,null);   
    }
    public Estudiante(){
        this("nombre","apellido",0,"usuario",0,null,null,null,null,null);
    }
    //METODO TO STRING//
    @Override
    public String toString() {
        return "\n"+"nombre: "+this.getNombre()+"\n"+"apellido: "
        +this.getApellido()+"\n"+"Id: "+this.getId()+"\n"+
        "usuario: "+this.getUsuario()+"\n"+
        "promedio: "+this.getPromedio()+"\n"+
        "programa academico: "+this.getProgramaAcademico().getNombre()+"\n"
        
        //"creditos: "+this.getCreditos()+"\n"+"cursos: "+this.getCursos()+"\n"+"grupos: "+this.getGrupos()+"\n"+"notas: "+this.getNotas()+"\n"
        ;
    }
    //ATRIBUTOS//
    public String getNombre(){
        return this.nombre;
    }
    public String getApellido(){
        return this.apellido;
    }
    public long getId(){
        return this.Id;
    }
    public String getUsuario(){
        return this.usuario;    
    }
    public double getPromedio(){
        return this.promedio;
    }

    public Programa_academico getProgramaAcademico(){
        return this.programaAcademico;
    }
    public Credito getCreditos(){
        return this.creditos;
    }
    public ArrayList<Curso> getCursos(){
        return this.cursos;
    
    }
    public ArrayList<Grupo> getGrupos(){
        return this.grupos;
    }
    public ArrayList<Nota> getNotas(){
        return this.notas;
    }
    public void setNombre(String nombre){
        this.nombre=nombre;
    }
    public void setApellido(String apellido){
        this.apellido=apellido;
    }
    public void setId(long Id){
        this.Id=Id;
    }
    public void setUsuario(String usuario){
        this.usuario=usuario;
    }
    public void setPromedio(double promedio){
        this.promedio=promedio;
    }
    public void setProgramaAcademico(Programa_academico programaAcademico){
        this.programaAcademico=programaAcademico;
    }
    public void setCreditos(Credito creditos){
        this.creditos=creditos;
    }
    public void setCursos(ArrayList<Curso> cursos){
        this.cursos=cursos;
    }
    public void setGrupos(ArrayList<Grupo> grupos){
            this.grupos=grupos;    
    }
    public void setNotas(ArrayList<Nota> notas){
        this.notas=notas;    
    }
}

