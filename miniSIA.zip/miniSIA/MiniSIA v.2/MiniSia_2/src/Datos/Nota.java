package Datos;

public class Nota {
        //METODO//
        private Estudiante estudiante;
        private Curso curso;
        private Grupo grupo;
        private double nota;
        //constructores//
        public Nota(Estudiante estudiante,Curso curso,Grupo grupo,double nota){
            this.setEstudiante(estudiante);
            this.setCurso(curso);
            this.setGrupo(grupo);
            this.setNota(nota);
        }
        public Nota(Estudiante estudiante){
            this(estudiante,null,null,0);
        }
        public Nota(){
            this(null,null,null,0);
        }
        //METODO TO STRING//
        @Override
        public String toString() {
        return "\n"+"estudiante: "+this.getEstudiante().getNombre()+"\n"+
        "curso: "+this.getCurso().getNombre()+"\n"+
        "grupo: "+this.getGrupo().getNumero()+"\n"+    
        "nota: "+this.getNota();

        }
        //ATRIBUTOS//
        public Estudiante getEstudiante(){
            return this.estudiante;
        }
        public Curso getCurso(){
            return this.curso;
        }
        public Grupo getGrupo(){
            return this.grupo;
        }
        public double getNota(){
            return this.nota;    
        }
        public void setEstudiante(Estudiante estudiante){
            this.estudiante=estudiante;

        }
        public void setCurso(Curso curso){
            this.curso=curso;
        }

        public void setGrupo(Grupo grupo){
            this.grupo=grupo;
        }
        public void setNota(double nota){
            this.nota=nota;
        }
    

    
}
