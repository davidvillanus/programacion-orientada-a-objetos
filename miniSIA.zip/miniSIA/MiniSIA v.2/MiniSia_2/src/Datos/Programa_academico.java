package Datos;

import java.util.ArrayList;

public class Programa_academico {
        //METODO//
        private String nombre;
        private int codigo;
        private ArrayList<Profesor> profesores;
        private ArrayList<Estudiante> estudiantes;
        private ArrayList<Curso>cursos;
        //constructores//
        public Programa_academico(String nombre,int codigo,
        ArrayList<Profesor> profesores, ArrayList<Estudiante> estudiantes,
        ArrayList<Curso> cursos){
            this.setNombre(nombre);
            this.setCodigo(codigo);
            this.setProfesores(profesores);
            this.setEstudiantes(estudiantes);
            this.setCursos(cursos);
        }
        public Programa_academico(String nombre,int codigo){
            this(nombre,codigo,null,null,null);
        }
        public Programa_academico(){
            this("nombre",0,null,null,null);
        }
        //METODO TO STRING//
        @Override
        public String toString() {
        return "\n"+"nombre: "+this.getNombre()+"\n"+
        "codigo: "+this.getCodigo()
       // "profesores: "+this.getProfesores()+"\n"+    "estudiantes: "+this.getEstudiantes()+"\n"+"cursos: "+this.getCursos()+"\n"
        ;

        }
        //ATRIBUTOS//
        public String getNombre(){
            return this.nombre;
        }
        public int getCodigo(){
            return this.codigo;
        }
        public ArrayList<Profesor> getProfesores(){
            return this.profesores;
        }
        public ArrayList<Estudiante> getEstudiantes(){
            return this.estudiantes;
        }
        public ArrayList<Curso> getCursos(){
            return this.cursos;
        }
        public void setNombre(String nombre){
            this.nombre=nombre;
        }
        public void setCodigo(int codigo){
            this.codigo=codigo;
        }
        public void setProfesores(ArrayList<Profesor> profesores){
            this.profesores=profesores;
        }
        public void setEstudiantes(ArrayList<Estudiante> estudiantes){
            this.estudiantes=estudiantes;
        }
        public void setCursos(ArrayList<Curso> cursos){
            this.cursos=cursos;
        }


    
}
