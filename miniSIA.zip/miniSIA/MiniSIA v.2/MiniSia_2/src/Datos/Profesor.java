package Datos;

import java.util.ArrayList;

public class Profesor {

    //METODO//
    private String nombre;
    private String apellido;
    private long Id;
    private String usuario;
    private Programa_academico programaAcademico;
    private ArrayList<Curso> cursos;
    private ArrayList<Grupo> grupos;                    
    //constructores//
    public Profesor(String nombre,String apellido,long Id,String usuario,
    Programa_academico programa_academico,ArrayList<Curso> cursos,
    ArrayList<Grupo> grupos){
        this.setNombre(nombre);
        this.setApellido(apellido);
        this.setId(Id);
        this.setUsuario(usuario);
        this.setProgramaAcademico(programaAcademico);
        this.setCursos(cursos);
        this.setGrupos(grupos);

    }
    public Profesor(String nombre,String apellido,long Id,String usuario){
        this(nombre,apellido,Id,usuario,null,null,null);   
    }
    public Profesor(String nombre,String apellido){
        this(nombre,apellido,0,"usuario",null,null,null);   
    }
    public Profesor(){
        this("nombre","apellido",0,"usuario",null,null,null);
    }
    //METODO TO STRING//
    @Override
    public String toString() {
        return "\n"+"nombre: "+this.getNombre()+"\n"+"apellido: "
        +this.getApellido()+"\n"+"Id: "+this.getId()+"\n"+
        "usuario: "+this.getUsuario();
        /*"programa academico: "+this.getProgramaAcademico()+"\n"+
        "cursos: "+this.getCursos()+"\n"+
        "grupos: "+this.getGrupos()+"\n";*/
    }
    //ATRIBUTOS//
    public String getNombre(){
        return this.nombre;
    }
    public String getApellido(){
        return this.apellido;
    }
    public long getId(){
        return this.Id;
    }
    public String getUsuario(){
        return this.usuario;    
    }

    public Programa_academico getProgramaAcademico(){
        return this.programaAcademico;
    }

    public ArrayList<Curso> getCursos(){
        return this.cursos;
    }
    public ArrayList<Grupo> getGrupos(){
        return this.grupos;
    }
    public void setNombre(String nombre){
        this.nombre=nombre;
    }
    public void setApellido(String apellido){
        this.apellido=apellido;
    }
        public void setId(long Id){
        this.Id=Id;
    }
    public void setUsuario(String usuario){
        this.usuario=usuario;
    }
    public void setProgramaAcademico(Programa_academico programaAcademico){
        this.programaAcademico=programaAcademico;
    }

    public void setCursos(ArrayList<Curso> cursos){
        this.cursos=cursos;
    }
    public void setGrupos(ArrayList<Grupo> grupos){
        this.grupos=grupos;
    }
}
