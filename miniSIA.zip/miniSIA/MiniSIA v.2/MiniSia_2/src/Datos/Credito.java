package Datos;

public class Credito {
    //metodos//
    private Estudiante estudiante;
    private int aprobados;
    private int disponibles;
    private int inscritos;
    //constructores//
    public Credito(Estudiante estudiante ,int aprobados ,int disponibles, int inscritos){
        this.setEstudiante(estudiante);
        this.setAprobados(aprobados);
        this.setDisponibles(disponibles);
        this.setInscritos(inscritos);
    }
    public Credito(Estudiante estudiante, int aprobados,int disponibles){
        this(estudiante,aprobados,disponibles,0);
    }
    public Credito(){
        this(null,0,0,0);
    }
    //METODO TO STRING//
    @Override
    public String toString() {
        return "\n"+"estudiante: "+this.geteEstudiante().getNombre()+"\n"+"creditos aprobados: "+this.getAprobados()+"\n"+
        "creditos disponibles: "+this.getDisponibles()+"\n"+    
        "creditos inscritos: "+this.getInscritos();
    }
    //atributos//
    public Estudiante geteEstudiante(){
        return this.estudiante;
    }
    public int getAprobados(){
        return this.aprobados;
    }
    public int getDisponibles(){
        return this.disponibles;
    }
    public int getInscritos(){
        return this.inscritos;
    }
    public void setEstudiante(Estudiante estudiante){
        this.estudiante=estudiante;
    }
    public void setAprobados(int aprobados){
        this.aprobados=aprobados;
    }
    public void setDisponibles(int disponibles){
        this.disponibles=disponibles;
    }
    public void setInscritos(int inscritos){
        this.inscritos=inscritos;
    }
    

    
}
