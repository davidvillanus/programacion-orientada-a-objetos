package Datos;

import java.util.ArrayList;
import java.util.Arrays;
public class Grupo {
        //METODO//
        private int numero;
        private String[] diasDeLaSemana;
        private String[] horasDelDia;
        private Profesor profesor;
        private Curso curso;
        private ArrayList<Estudiante> estudiantes;
        private ArrayList<Nota> Notas;
        //constructores//
        public Grupo(int numero,String[] diasDeLaSemana,String[] horasDelDia,
        Profesor profesor, Curso curso,ArrayList<Estudiante> estudiantes, ArrayList<Nota> notas ){
            this.setNumero(numero);
            this.setDiasDeLaSemana(diasDeLaSemana);
            this.setHorasDelDia(horasDelDia);
            this.setProfesor(profesor);
            this.setCurso(curso);
            this.setEstudiantes(estudiantes);
            this.setNotas(Notas);
        }
        public Grupo(int numero,String[] diasDeLaSemana,String[] horasDelDia,Profesor profesor ,Curso curso ){
            this(numero,diasDeLaSemana,horasDelDia,profesor,curso,null,null);
        }
        public Grupo(int numero,String[] diasDeLaSemana,String[] horasDelDia,Curso curso){
            this(numero,diasDeLaSemana,horasDelDia,null,curso,null,null);
        }
        public Grupo(){
            this(0,null,null,null,null,null,null);

        }
    //METODO TO STRING//
    @Override
    public String toString() {
        return "\n"+"numero: "+this.getNumero()+"\n"+
        "dias de la semana: "+Arrays.toString(this.getDiasDeLaSemana())+"\n"+
        "horas del dia: "+Arrays.toString(this.getHorasDelDia())+"\n"+    
        "profesor: "+this.getProfesor().getNombre()+"\n"+    
        "curso: "+this.getCurso().getNombre()+"\n"    
        //"estudiantes: "+ this.getEstudiantes()+"\n"+"notas: "+this.getNotas()
        ;
    }        
        //ATRIBUTOS//
        public int getNumero(){
            return this.numero;
        }
        public String [] getDiasDeLaSemana(){
            return this.diasDeLaSemana;  
        }
        public String [] getHorasDelDia(){
            return this.horasDelDia;  
        }
        public Profesor getProfesor(){
            return this.profesor;    
        }
        public Curso getCurso(){
            return this.curso;    
        }
        public ArrayList<Estudiante> getEstudiantes(){
            return this.estudiantes;
        }
        public ArrayList<Nota> getNotas(){
            return this.Notas;
        }

        public void setNumero(int numero){
            this.numero=numero;
        }
        public void setDiasDeLaSemana(String [] diasDeLaSemana){
            this.diasDeLaSemana=diasDeLaSemana;  
        }
        public void setHorasDelDia(String [] horasDelDia){
            this.horasDelDia=horasDelDia;  
        }
        public void setProfesor(Profesor profesor){
            this.profesor=profesor;
        }
        public void setCurso(Curso curso){
            this.curso=curso;
        }
        public void setEstudiantes(ArrayList<Estudiante> estudiantes){
            this.estudiantes=estudiantes;
        }
        public void setNotas(ArrayList<Nota> Notas){
            this.Notas=Notas;
        }
    
}
