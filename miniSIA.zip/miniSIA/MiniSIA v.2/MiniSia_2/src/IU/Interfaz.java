package IU;

import java.util.Scanner;


public class Interfaz {
    
     public static void imprimirBienvenida () {
        System.out.println("Bienvenid@ al mini Sistema de Informacion Academica"); 
    }
    public static int leerTeclado (){
        Scanner lector=new Scanner(System.in);
        int num= lector.nextInt();
        lector.close();
        return num;
        
        
    }
    
    public static void imprimirInformacion(){
        System.out.println("Precione 1 para visualizar la lista de Estudiantes ");
        System.out.println("Precione 2 para visualizar la lista de Profesores");
        System.out.println("Precione 3 para visualizar la lista de Cursos ");
        System.out.println("Precione 4 para visualizar la lista de programas academicos ");
        System.out.println("Precione 5 para visualizar la lista de Notas ");
        System.out.println("Precione 6 para visualizar la lista de Grupos ");
        System.out.println("Precione 7 para visualizar la lista de creditos ");
        
        
    }
    
}
