package lU;

import java.util.Scanner;
//import datos.Student;
//import datos.Professor;

public class Interfaz {

	public static void iniciar() {
		System.out.println("Te damos la bienvenida al mini SIA");
	}
	
	public static void preguntar() {
		System.out.println("�Qu� desea hacer?:"+"\n"+"1. Consultar estudiantes"+"\n"+"2. Consultar profesores"+"\n"+"3. Consultar semestre"+"\n"+"4. Consultar historia acad�mica"+"\n"+"5. Consultar cursos"+"\n"+"6. Consultar grupos de clases"+"\n"+"7. Consultar notas");
	}
	
	public static int retorNum()
	{
		Scanner select=new Scanner(System.in);
		int num = select.nextInt();
		select.close();
		return num;
	}
	
}
