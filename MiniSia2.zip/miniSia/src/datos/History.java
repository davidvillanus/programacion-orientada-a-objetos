package datos;

public class History {
	
	Student estudiante;
	Course curso;
	Grade nota;
	Semester semestre;
	
	public Student getEstudiante() {
		return this.estudiante;
	}
	
	public Course getCurso() {
		return this.curso;
	}
	
	public Grade getNota() {
		return this.nota;
	}
	
	public Semester getSemestre() {
		return this.semestre;
	}
	
	public void setEstudiante(Student estudiante) {
		this.estudiante = estudiante;
	}
	
	public void setCurso(Course curso) {
		this.curso = curso;
	}
	
	public void setNota(Grade nota) {
		this.nota = nota;
	}
	
	public void setSemestre(Semester semestre) {
		this.semestre = semestre;
	}

	//INTERACCI�N
	
	public History(Student estudiante, Course curso, Grade nota, Semester semestre) {
		this.setEstudiante(estudiante);
		this.setCurso(curso);
		this.setNota(nota);
		this.setSemestre(semestre);
	}
	
	public History(Student estudiante, Course curso, Grade nota) {
		this(estudiante, curso, nota, null);
	}
	
	public History(Student estudiante, Course curso) {
		this(estudiante, curso, null, null);
	}
	
	public History(Student estudiante) {
		this(estudiante, null, null, null);
	}
	
	public History() {
		this(null, null, null, null);
	}
	
	@Override
	public String toString() {
		return "Estudiante: "+"\n"+this.getEstudiante()+"\n"+"Cursa actualmente: "+this.getCurso().getNombre()+"\n"+"Nota: "+this.getNota().getNota()+"\n"+this.getSemestre()+"\n"+"--------------------";
	}
}
