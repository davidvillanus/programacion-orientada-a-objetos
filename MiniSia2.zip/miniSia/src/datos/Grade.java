package datos;

public class Grade {

	Student estudiante;
	Course curso;
	Group grupo;
	double nota;
	
	public Student getEstudiante() {
		return this.estudiante;
	}
	
	public Group getGrupo() {
		return this.grupo;
	}
	
	public double getNota() {
		return this.nota;
	}
	
	public Course getCurso() {
		return this.curso;
	}
	
	public void setEstudiante(Student estudiante) {
		this.estudiante = estudiante;
	}
	
	public void setGrupo(Group grupo) {
		this.grupo = grupo;
	}
	
	public void setNota(double nota) {
		this.nota = nota;
	}

	public void setCurso(Course curso) {
		this.curso = curso;
	}
	
	//INTERACCI�N
	
	public Grade(Student estudiante, Course curso, Group grupo, double nota) {
		this.setEstudiante(estudiante);
		this.setGrupo(grupo);
		this.setNota(nota);
		this.setCurso(curso);
	}
	
	public Grade(Student estudiante, Course curso, Group grupo) {
		this(estudiante, curso, grupo, 0);
	}
	
	public Grade(Student estudiante, Course curso) {
		this(estudiante, curso, null, 0);
	}
	
	public Grade(Student estudiante) {
		this(estudiante, null, null, 0);
	}
	
	public Grade(double nota) {
		this(null, null, null, nota);
	}
	
	public Grade() {
		this(null, null, null, 0);
	}
	
	@Override
	public String toString() {
		return "Estudiante: "+this.getEstudiante().getNombre()+" "+this.getEstudiante().getApellido()+"\n"+"Curso: "+this.getCurso().getNombre()+"\n"+"Grupo: "+this.getGrupo().getNumero()+"\n"+"Nota: "+this.getNota()+"\n";
	}
}
