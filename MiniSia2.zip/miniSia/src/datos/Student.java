package datos;

import java.util.List;

public class Student {
	
	private String usuario;
	private String nombre;
	private String apellido;
	private int edad;
	private double papa;
	private List<Group> asistencia;
	
	public String getUsuario() {
		return this.usuario;
	}
	
	public String getNombre() {
		return this.nombre;
	}

	public String getApellido() {
		return this.apellido;
	}
	
	public int getEdad() {
		return this.edad;
	}

	public double getPapa() {
		return this.papa;
	}
	
	public List<Group> getAsistencia() {
		return this.asistencia;
	}
	
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}
	
	public void setEdad(int edad) {
		this.edad = edad;
	}
	
	public void setPapa(double papa) {
		this.papa = papa;
	}
	
	public void setGrupo(List<Group> asistencia) {
		this.asistencia = asistencia;
	}

	// INTERACCI�N
	
	public Student(String usuario, String nombre, String apellido, int edad, double papa) {
		this.setUsuario(usuario);
		this.setNombre(nombre);
		this.setApellido(apellido);
		this.setEdad(edad);
		this.setPapa(papa);
	}
	
	public Student(String usuario, String nombre, String apellido, int edad) {
		this(usuario, nombre, apellido, edad, 0);
	}
	
	public Student(String usuario, String nombre, String apellido) {
		this(usuario, nombre, apellido, 0, 0);
	}
	
	public Student(String usuario, String nombre) {
		this(usuario, nombre, null, 0, 0);
	}
	
	public Student(String nombre) {
		this(null, nombre, null, 0, 0);
	}
	
	public Student() {
		this(null, null, null, 0, 0);
	}
	
	@Override
	public String toString() {
		return "Usuario SIA: "+this.getUsuario()+"\n"+"Nombre: "+this.getNombre()+"\n"+"Apellido: "+this.getApellido()+"\n"+"Edad: "+this.getEdad()+" a�os"+"\n"+"PAPA: "+this.getPapa()+"\n";
	}
	
}
