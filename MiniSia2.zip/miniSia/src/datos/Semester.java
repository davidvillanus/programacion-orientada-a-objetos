package datos;

public class Semester {
	
	private int a�o;
	private String semestre;
	
	public int getA�o() {
		return this.a�o;
	}
	
	public String getSemestre() {
		return this.semestre;
	}
	
	public void setA�o(int a�o) {
		this.a�o = a�o;
	}
	
	// INTERACCI�N
	
	public void setSemestre(String semestre) {
		this.semestre = semestre;
	}

	public Semester(int a�o, String semestre) {
		this.setA�o(a�o);
		this.setSemestre(semestre);
	}
	
	public Semester(String semestre) {
		this(2020, semestre);
	}
	
	public Semester() {
		this(2020, null);
	}
	
	@Override
	public String toString() {
		return "Semestre en curso: "+this.getA�o()+"-"+this.getSemestre();
	}
}
