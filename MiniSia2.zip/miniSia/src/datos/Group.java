package datos;

import java.util.Arrays;
import java.util.List;

public class Group {

	private long numero;
	private String[] diasSemana;
	private String[] horasDia;
	private Semester semestre;
	private Course curso;
	private Professor dadoPor;
	private List<Student> tomadoPor;
	private List<Grade> notas;
	
	public long getNumero() {
		return this.numero;
	}
	
	public String[] getDiasSemana() {
		return this.diasSemana;
	}
	
	public String[] getHorasDia() {
		return this.horasDia;
	}
	
	public Semester getSemestre() {
		return this.semestre;
	}
	
	public Course getCurso() {
		return this.curso;
	}
	
	public Professor getDadoPor() {
		return this.dadoPor;
	}
	
	public List<Student> getTomadoPor() {
		return this.tomadoPor;
	}
	
	public List<Grade> getNotas() {
		return this.notas;
	}
	
	public void setNumero(long numero) {
		this.numero = numero;
	}
	
	public void setDiasSemana(String[] diasSemana) {
		this.diasSemana = diasSemana;
	}
	
	public void setHorasDia(String[] horasDia) {
		this.horasDia = horasDia;
	}
	
	public void setSemestre(Semester semestre) {
		this.semestre = semestre;
	}
	
	public void setCurso(Course curso) {
		this.curso = curso;
	}
	
	public void setDadopor(Professor dadoPor) {
		this.dadoPor = dadoPor;
	}
	
	public void setTomadopor(List<Student> tomadoPor) {
		this.tomadoPor = tomadoPor;
	}
	
	public void setNotas(List<Grade> notas) {
		this.notas = notas;
	}
	
	//INTERACCI�N
	
	public Group(long numero, String[] diasSemana, String[] horasDia, Semester semestre, Course curso, Professor dadoPor) {
		this.setNumero(numero);
		this.setDiasSemana(diasSemana);
		this.setHorasDia(horasDia);
		this.setSemestre(semestre);
		this.setCurso(curso);
		this.setDadopor(dadoPor);
	}
	
	public Group(long numero, String[] diasSemana, String[] horasDia, Semester semestre, Course curso) {
		this(numero, diasSemana, horasDia, semestre, curso, null);
	}
	
	public Group(long numero, String[] diasSemana, String[] horasDia, Semester semestre) {
		this(numero, diasSemana, horasDia, semestre, null, null);
	}
	
	public Group(long numero, String[] diasSemana, String[] horasDia) {
		this(numero, diasSemana, horasDia, null, null, null);
	}
	
	public Group(long numero, String[] diasSemana) {
		this(numero, diasSemana, null, null, null, null);
	}
	
	public Group(long numero) {
		this(numero, null, null, null, null, null);
	}
	
	public Group() {
		this(0, null, null, null, null, null);
	}
	
	@Override
	public String toString() {
		return "Curso:"+this.getCurso().getNombre()+"\n"+"Grupo # "+this.getNumero()+"\n"+"Dias a la semana: "+Arrays.toString(this.getDiasSemana())+"\n"+"Horas al d�a: "+Arrays.toString(this.getHorasDia())+"\n";
	}
	
}
