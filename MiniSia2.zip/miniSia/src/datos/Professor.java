package datos;

import java.util.List;

public class Professor {
	
	private String usuario;
	private String nombre;
	private String apellido;
	private int edad;
	private Course curso;
	private List<Group> grupoTomado;
	
	public String getUsuario() {
		return this.usuario;
	}
	
	public String getNombre() {
		return this.nombre;
	}

	public String getApellido() {
		return this.apellido;
	}
	
	public int getEdad() {
		return this.edad;
	}
	
	public Course getCurso() {
		return this.curso;
	}

	public List<Group> getGrupoTomado() {
		return this.grupoTomado;
	}
	
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}
	
	public void setEdad(int edad) {
		this.edad = edad;
	}
	
	public void setCurso(Course curso) {
		this.curso = curso;
	}
	
	public void setGrupo(List<Group> grupoTomado) {
		this.grupoTomado = grupoTomado;
	}
	
	public Professor(String usuario, String nombre, String apellido, int edad, Course curso) {
		this.setUsuario(usuario);
		this.setNombre(nombre);
		this.setApellido(apellido);
		this.setEdad(edad);
		this.setCurso(curso);
	}
	
	public Professor(String usuario, String nombre, String apellido, Course curso) {
		this(usuario, nombre, apellido, -1, curso);
	}
	
	public Professor(String usuario, String nombre, String apellido) {
		this(usuario, nombre, apellido, -1, null);
	}	
	
	public Professor(String nombre, String apellido) {
		this(null, nombre, apellido, -1, null);
	}	
	
	public Professor(String nombre) {
		this(null, nombre, null, -1, null);
	}	
	
	public Professor() {
		this(null, null, null, -1, null);
	}	

	@Override
	public String toString() {
		return "Usuario: "+this.getUsuario()+"\n"+"Nombre: "+this.getNombre()+"\n" + "Apellido: " +this.getApellido()+"\n" + "Edad: " +this.getEdad()+" a�os"+"\n"+"Asignatura que dicta: "+this.getCurso()+"\n";
	}
		
}
