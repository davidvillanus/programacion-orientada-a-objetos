package logic;

import datos.Student;
import datos.Professor;
import datos.Semester;
import datos.History;
import datos.Course;
import datos.Grade;
import datos.Group;
import lU.Interfaz;

public class Logic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] dgA = {"Lunes","Mi�rcoles"};
		String[] dgB = {"Martes","Jueves"};
		String[] hgA = {"7:00 a 9:00","7:00 a 9:00"};
		String[] hgB = {"9:00 a 11:00","9:00 a 11:00"};

		Student stuA = new Student("luahernandezdu","Luis","Hern�ndez",25,4.1);
		Student stuB = new Student("mahernandezd","Alexandra","Hern�ndez");
		Course curA = new Course(1,"Programaci�n I");
		Course curB = new Course(2,"Programaci�n II");
		Professor proA = new Professor("lcdiazf","Luis");
		Professor proB = new Professor("agochoad","Alexei","Ochoa");
		
		proA.setCurso(curA);
		proB.setCurso(curB);
		
		Semester sem1 = new Semester(2021, "I");

		Group gruA = new Group(1,dgA,hgA);
		Group gruB = new Group(2,dgB,hgB);
		
		gruA.setSemestre(sem1);
		gruA.setCurso(curA);
		gruA.setDadopor(proA);
		gruB.setSemestre(sem1);
		gruB.setCurso(curB);
		gruB.setDadopor(proB);
		
		Grade graA = new Grade(4.5);
		Grade graB = new Grade(3.3);
		
		graA.setEstudiante(stuA);
		graA.setCurso(curA);
		graA.setGrupo(gruA);
		graB.setEstudiante(stuB);
		graB.setCurso(curB);
		graB.setGrupo(gruB);
		
		History hisA = new History();
		History hisB = new History();
		
		hisA.setEstudiante(stuA);
		hisA.setCurso(curA);
		hisA.setNota(graA);
		hisA.setSemestre(sem1);
		hisB.setEstudiante(stuB);
		hisB.setCurso(curB);
		hisB.setNota(graB);
		hisB.setSemestre(sem1);
		
		Interfaz.iniciar();
		Interfaz.preguntar();
		int op =Interfaz.retorNum();
		switch (op) {
		case 1:
			System.out.println(stuA.toString());
			System.out.println(stuB.toString());
			break;
		case 2:
			System.out.println(proA.toString());
			System.out.println(proB.toString());
			break;
		case 3:
			System.out.println(sem1.toString());
			break;
		case 4:
			System.out.println(hisA.toString());
			System.out.println(hisB.toString());
			break;
		case 5:
			System.out.println(curA.toString());
			System.out.println(curB.toString());
			break;
		case 6:
			System.out.println(gruA.toString());
			System.out.println(gruB.toString());
			break;
		case 7:
			System.out.println(graA.toString());
			System.out.println(graB.toString());
			break;
		default: 
			System.out.println("Opci�n incorrecta");
			break;
		}//Switch
		
	}//Main

}//class
