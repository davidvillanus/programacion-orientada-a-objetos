package Ahorcadito;

import java.util.Random;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		String palabraEscogida = getEscogePalabra();
		String guiones[] = getGuionesArray(palabraEscogida);
		play(palabraEscogida, guiones);
		System.out.println("La palabra era: " + palabraEscogida);
		
	}
	
	static String getEscogePalabra() {
		String[] palabras = {"teclado", "mouse", "pantalla", "procesador", "discoduro", "memoriaram", "parlantes", "mainboard", "camara", "fuente"};
		Random r = new Random();
		int n = r.nextInt(palabras.length);
		
		return palabras[n];
	}
	
	static String[] getGuionesArray(String palabra) {
		
		int nLetras = palabra.length();
		String [] LetrasAdivinar= new String[nLetras];
		
		// LLENA ARREGLO CON GUIONES
		for (int i=0 ; i<LetrasAdivinar.length; i++) {
			LetrasAdivinar[i] = "_";
		}	
		return LetrasAdivinar;
	}
	
	static void play(String palabraEscogida, String[] guiones) {
		String[] palabra = palabraEscogida.split("");
		
		boolean end = false;
		Scanner lectura = new Scanner(System.in); 
		int intentos = 7;
		
		while(!end) {
			boolean acierto = false;
			
			System.out.println("Intentos: " + intentos);
			System.out.println("Adivinando: ");
			for(int j=0; j<guiones.length;j++) {
				System.out.print(guiones[j]);
			}
			System.out.println(" ");
			System.out.println("Introduzca una letra...");
			String letra = lectura.next();
			
			for(int i=0 ; i<palabra.length ; i++) {
				boolean cond = palabra[i].equals(letra);
				if (cond == true) {
					guiones[i] = letra;
					acierto = true;
				}
			}//for
				if (acierto == false) {
						System.out.println("No has acertado :(");
						intentos--;
						if(intentos == 0) {
							System.out.println("�Has perdido!");
							end = true;
						}
					}else {
						boolean compruebaGuiones = compruebaGuiones(guiones);
						if(compruebaGuiones == false) {
							System.out.println("�Ganaste! :3");
							end = true;
							}
						}
		}//while
		lectura.close();
	}//static void play

	static boolean compruebaGuiones (String[] guiones) {
		for(int i=0 ; i<guiones.length ; i++) {
			if (guiones[i] == "_")return true;
		} return false;
	}//bool guiones
	
}//Main